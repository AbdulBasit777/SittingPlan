﻿using SittingPlan_AOA_Project_.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SittingPlan_AOA_Project_
{
    public partial class FormResources : Form
    {
        
        public FormResources()
        {
            InitializeComponent();
        }

        private void Resources_Load(object sender, EventArgs e)
        {
            Display();
        }

        public void Display()
        {
            dataGridViewResources.DataSource = DatabaseConnections.DisplayData();
        }

        private void btnAddResource_Click(object sender, EventArgs e)
        {
            if(txtResourceName.Text.Trim() == string.Empty || txtResourceCapacity.Text.Trim() == string.Empty)
            {
                MessageBox.Show("All Fields must be filled");
            }
            else
            {
                DatabaseConnections.AddResources(txtResourceName.Text, txtResourceCapacity.Text);
                Display();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtDeleteResource.Text.Trim() != string.Empty)
            {
                DatabaseConnections.DeleteResources(txtDeleteResource.Text);
                Display();
            }
        }
    }
}
