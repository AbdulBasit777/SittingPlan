﻿using SittingPlan_AOA_Project_.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace SittingPlan_AOA_Project_
{
    public partial class FormSeatingPlan : Form
    {
        string selectedFilePath;
        string destinationPath;

        public FormSeatingPlan()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private static bool IsDigitsOnly(string str)
        {
            foreach (char c in str)
            {
                if (c < '0' || c > '9')
                    return false;
            }

            return true;
        }

        private void btnBrowseFile_Click(object sender, EventArgs e)
        {
            fileDialogeBrowse.CheckFileExists = true;
            fileDialogeBrowse.CheckPathExists = true;
            fileDialogeBrowse.Multiselect = false;
            fileDialogeBrowse.RestoreDirectory = true;
            fileDialogeBrowse.Title = "Select Excel Files";
            fileDialogeBrowse.Filter = "Excel Files (*.xlsx)|*.xlsx";
            fileDialogeBrowse.ShowDialog();
            selectedFilePath = fileDialogeBrowse.FileName;
            txtFileName.Text = fileDialogeBrowse.SafeFileName;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public static void MergeSort(List<KeyValuePair<int, string>> arr, int startIndex, int endIndex)
        {
            if (startIndex < endIndex)
            {
                int middle = startIndex + (endIndex - startIndex) / 2;

                MergeSort(arr, startIndex, middle);
                MergeSort(arr, middle + 1, endIndex);

                Merge(arr, startIndex, middle, endIndex);
            }
        }

        private static void Merge(List<KeyValuePair<int, string>> arr, int left, int middle, int right)
        {
            int i, j, k;
            int leftSubArraySize = middle - left + 1;
            int rightSubArraySize = right - middle;

            List<KeyValuePair<int, string>> leftSubArray = new List<KeyValuePair<int, string>>();
            List<KeyValuePair<int, string>> rightSubArray = new List<KeyValuePair<int, string>>();

            for (i = 0; i < leftSubArraySize; i++)
            {
                leftSubArray.Add(arr[left + i]);
            }
            for (j = 0; j < rightSubArraySize; j++)
            {
                rightSubArray.Add(arr[middle + 1 + j]);
            }

            i = 0;
            j = 0;
            k = left;
            while (i < leftSubArraySize && j < rightSubArraySize)
            {
                if (IsDigitsOnly(leftSubArray[i].Value) && IsDigitsOnly(rightSubArray[j].Value))
                {
                    if (Convert.ToInt32(leftSubArray[i].Value) <= Convert.ToInt32(rightSubArray[j].Value))
                    {
                        arr[k] = leftSubArray[i];
                        i++;
                    }
                    else
                    {
                        arr[k] = rightSubArray[j];
                        j++;
                    }
                    k++;
                }
                else
                {
                    if (string.Compare(leftSubArray[i].Value, rightSubArray[j].Value) != 1)
                    {
                        arr[k] = leftSubArray[i];
                        i++;
                    }
                    else
                    {
                        arr[k] = rightSubArray[j];
                        j++;
                    }
                    k++;
                }
            }

            while (i < leftSubArraySize)
            {
                arr[k] = leftSubArray[i];
                i++;
                k++;
            }

            while (j < rightSubArraySize)
            {
                arr[k] = rightSubArray[j];
                j++;
                k++;
            }
        }

        private void btnBrowseFolder_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowNewFolderButton = true;
            folderBrowserDialog1.ShowDialog();
            destinationPath = folderBrowserDialog1.SelectedPath;
            //txtFolderName.Text = Path.GetFileNameWithoutExtension(destinationPath);
            txtFolderName.Text = destinationPath;
        }

        private void btnStartProcess_Click(object sender, EventArgs e)
        {
            if (txtEventName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please Enter event name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (txtFileName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please Select an Input File", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (txtFolderName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please Select a Folder for Output File", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (txtOutputFileName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Write Output File Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (txtColNameSittingPlan.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Write Column Name for sitting plan", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Excel.Application xlAppCreate = new Microsoft.Office.Interop.Excel.Application();
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlAppCreate.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            Excel.Application xlApp = new Excel.Application();
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(selectedFilePath);
            Excel._Worksheet xlWorksheet1 = xlWorkbook.Sheets[1];
            Excel.Range xlRange1 = xlWorksheet1.UsedRange;

            int i = 1;
            int colIndex = 0;
            bool colFound = false;
            while (xlRange1.Cells[1, i] != null)
            {
                if (xlRange1.Cells[1, i].value.ToString().Trim() == txtColNameSittingPlan.Text)
                {
                    colFound = true;
                    colIndex = i;
                    break;
                }
                i++;
            }

            if (colFound == false)
            {
                MessageBox.Show("Column name for sitting plan does not exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            List<KeyValuePair<int, string>> keyValuesList = new List<KeyValuePair<int, string>>();
            for (int j = 2; j <= xlRange1.Rows.Count; j++)
            {
                string value = xlRange1.Cells[j, colIndex].value.ToString();
                int rowIndex = j;
                KeyValuePair<int, string> keyValue = new KeyValuePair<int, string>(rowIndex, value);
                keyValuesList.Add(keyValue);
            }

            MergeSort(keyValuesList, 0, keyValuesList.Count - 1);

            int z = -1;
            for (int j = 1; j <= xlRange1.Rows.Count; j++)
            {
                i = 1;
                while (xlRange1.Cells[j, i].value != null)
                {
                    if (j == 1)
                    {
                        xlWorkSheet.Cells[j, i] = xlRange1.Cells[1, i].value.ToString();
                    }
                    else
                    {
                        xlWorkSheet.Cells[j, i] = xlRange1.Cells[keyValuesList[z].Key, i].value.ToString();
                    }
                    i++;
                }
                z++;
            }

            DataTable dataTable = new DataTable();
            dataTable = DatabaseConnections.GetResourcesCapacity();
            List<KeyValuePair<int, string>> resources = new List<KeyValuePair<int, string>>();
            foreach (DataRow item in dataTable.Rows)
            {
                KeyValuePair<int, string> keyValue = new KeyValuePair<int, string>(Convert.ToInt32(item["Capacity"].ToString()), item["Name"].ToString());
                resources.Add(keyValue);
            }

            int fullCapacity = 0;
            foreach (var item in resources)
            {
                fullCapacity += item.Key;
            }

            if (fullCapacity < xlRange1.Rows.Count - 1)
            {
                MessageBox.Show("Capacity Underflow! Add more resources", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int roomNo = 1;
            int roomIndex = 0;
            for (int j = 1; j <= xlRange1.Rows.Count; j++)
            {
                if (j == 1)
                {
                    xlWorkSheet.Cells[j, xlRange1.Columns.Count + 1] = "Room Allotted";
                }
                else
                {
                    if(roomNo > resources[roomIndex].Key)
                    {
                        roomIndex++;
                        roomNo = 1;
                    }
                    xlWorkSheet.Cells[j, xlRange1.Columns.Count + 1] = resources[roomIndex].Value;
                    roomNo++;
                }
            }

            xlWorkBook.SaveAs(destinationPath + "\\" + txtOutputFileName.Text + ".xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();

            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            Marshal.ReleaseComObject(xlApp);

            //xlWorkbook.Close(true, misValue, misValue);
            xlAppCreate.Quit();

            Marshal.ReleaseComObject(xlWorksheet1);
            Marshal.ReleaseComObject(xlWorkbook);
            Marshal.ReleaseComObject(xlAppCreate);

            MessageBox.Show("A file with sitting plan has been generated successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btnResources_Click(object sender, EventArgs e)
        {
            FormResources form = new FormResources();
            form.ShowDialog();
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            History form = new History();
            form.ShowDialog();
        }
    }
}
