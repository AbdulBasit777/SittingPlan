﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace SittingPlan_AOA_Project_.Classes
{
    public class DatabaseConnections
    {
        private static string cs = "Data Source=DESKTOP-I0IE73N;Initial Catalog=SittingPlan;Integrated Security=True";
        private static SqlConnection cn = new SqlConnection(cs);

        private static void CheckConnectivity()
        {
            if (cn.State == ConnectionState.Open)
            {
                cn.Close();
            }
            cn.Open();
        }

        public static DataTable DisplayData()
        {
            CheckConnectivity();
            SqlCommand cmd = cn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select Name,Capacity from Resources";
            cmd.ExecuteNonQuery();
            DataTable dataTable = new DataTable();
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(cmd);
            sqlDataAdapter.Fill(dataTable);

            return dataTable;
        }

        private static bool CheckResources(string name)
        {
            try
            {
                CheckConnectivity();

                SqlCommand command = cn.CreateCommand();
                command.CommandType = CommandType.Text;

                command.CommandText = "SELECT [Name] FROM [dbo].[Resources] where [Name]=@Name";
                command.Parameters.AddWithValue("@Name", name);

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    reader.Close();
                    return false;
                }
                else
                {
                    reader.Close();
                    return true;
                }

            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public static DataTable GetResourcesCapacity()
        {
            CheckConnectivity();

            SqlCommand command = cn.CreateCommand();
            command.CommandType = CommandType.Text;

            command.CommandText = "SELECT [Name],[Capacity] FROM [dbo].[Resources]";

            command.ExecuteNonQuery();
            DataTable dataTable = new DataTable();
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command);
            sqlDataAdapter.Fill(dataTable);

            return dataTable;
        }

        public static bool AddResources(string name, string capacity)
        {
            try
            {
                CheckConnectivity();
                if (CheckResources(name))
                {
                    SqlCommand command = cn.CreateCommand();
                    command.CommandType = CommandType.Text;

                    command.CommandText = " INSERT INTO[dbo].[Resources]([Name],[Capacity]) VALUES(@Name,@Capacity)";
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Capacity", capacity);
                    command.ExecuteNonQuery();
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public static bool DeleteResources(string name)
        {
            try
            {
                CheckConnectivity();
                if (!CheckResources(name))
                {
                    SqlCommand command = cn.CreateCommand();
                    command.CommandType = CommandType.Text;

                    command.CommandText = "DELETE from [dbo].[Resources] where [Name] = @name";
                    command.Parameters.AddWithValue("@name", name);
                    command.ExecuteNonQuery();
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
