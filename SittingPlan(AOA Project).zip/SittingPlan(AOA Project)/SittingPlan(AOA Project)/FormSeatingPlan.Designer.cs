﻿namespace SittingPlan_AOA_Project_
{
    partial class FormSeatingPlan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStartProcess = new System.Windows.Forms.Button();
            this.txtFolderName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnBrowseFolder = new System.Windows.Forms.Button();
            this.fileDialogeBrowse = new System.Windows.Forms.OpenFileDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.label3 = new System.Windows.Forms.Label();
            this.txtOutputFileName = new System.Windows.Forms.TextBox();
            this.txtFileName = new System.Windows.Forms.TextBox();
            this.btnBrowseFile = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtColNameSittingPlan = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.rdBtnSame = new System.Windows.Forms.RadioButton();
            this.rdBtnDifferent = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.txtEventName = new System.Windows.Forms.TextBox();
            this.btnResources = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.btnHistory = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnStartProcess
            // 
            this.btnStartProcess.Location = new System.Drawing.Point(322, 386);
            this.btnStartProcess.Name = "btnStartProcess";
            this.btnStartProcess.Size = new System.Drawing.Size(101, 31);
            this.btnStartProcess.TabIndex = 13;
            this.btnStartProcess.Text = "Get Sitting Plan";
            this.btnStartProcess.UseVisualStyleBackColor = true;
            this.btnStartProcess.Click += new System.EventHandler(this.btnStartProcess_Click);
            // 
            // txtFolderName
            // 
            this.txtFolderName.Enabled = false;
            this.txtFolderName.Location = new System.Drawing.Point(321, 175);
            this.txtFolderName.Name = "txtFolderName";
            this.txtFolderName.Size = new System.Drawing.Size(154, 20);
            this.txtFolderName.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(245, 178);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Output Folder";
            // 
            // btnBrowseFolder
            // 
            this.btnBrowseFolder.Location = new System.Drawing.Point(481, 173);
            this.btnBrowseFolder.Name = "btnBrowseFolder";
            this.btnBrowseFolder.Size = new System.Drawing.Size(75, 23);
            this.btnBrowseFolder.TabIndex = 10;
            this.btnBrowseFolder.Text = "Browse";
            this.btnBrowseFolder.UseVisualStyleBackColor = true;
            this.btnBrowseFolder.Click += new System.EventHandler(this.btnBrowseFolder_Click);
            // 
            // fileDialogeBrowse
            // 
            this.fileDialogeBrowse.FileName = "openFileDialog1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(227, 232);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Output File Name";
            // 
            // txtOutputFileName
            // 
            this.txtOutputFileName.Location = new System.Drawing.Point(321, 229);
            this.txtOutputFileName.Name = "txtOutputFileName";
            this.txtOutputFileName.Size = new System.Drawing.Size(154, 20);
            this.txtOutputFileName.TabIndex = 15;
            // 
            // txtFileName
            // 
            this.txtFileName.Enabled = false;
            this.txtFileName.Location = new System.Drawing.Point(322, 123);
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.Size = new System.Drawing.Size(153, 20);
            this.txtFileName.TabIndex = 7;
            // 
            // btnBrowseFile
            // 
            this.btnBrowseFile.Location = new System.Drawing.Point(481, 121);
            this.btnBrowseFile.Name = "btnBrowseFile";
            this.btnBrowseFile.Size = new System.Drawing.Size(75, 23);
            this.btnBrowseFile.TabIndex = 8;
            this.btnBrowseFile.Text = "Browse";
            this.btnBrowseFile.UseVisualStyleBackColor = true;
            this.btnBrowseFile.Click += new System.EventHandler(this.btnBrowseFile_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(234, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Input FIle Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 285);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(280, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Column Name of file on which Sitting Plan is to be devised";
            // 
            // txtColNameSittingPlan
            // 
            this.txtColNameSittingPlan.Location = new System.Drawing.Point(322, 282);
            this.txtColNameSittingPlan.Name = "txtColNameSittingPlan";
            this.txtColNameSittingPlan.Size = new System.Drawing.Size(153, 20);
            this.txtColNameSittingPlan.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(208, 330);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Criteria for sitting Plan";
            this.label5.Visible = false;
            // 
            // rdBtnSame
            // 
            this.rdBtnSame.AutoSize = true;
            this.rdBtnSame.Location = new System.Drawing.Point(322, 328);
            this.rdBtnSame.Name = "rdBtnSame";
            this.rdBtnSame.Size = new System.Drawing.Size(108, 17);
            this.rdBtnSame.TabIndex = 19;
            this.rdBtnSame.TabStop = true;
            this.rdBtnSame.Text = "People with same";
            this.rdBtnSame.UseVisualStyleBackColor = true;
            this.rdBtnSame.Visible = false;
            // 
            // rdBtnDifferent
            // 
            this.rdBtnDifferent.AutoSize = true;
            this.rdBtnDifferent.Location = new System.Drawing.Point(322, 351);
            this.rdBtnDifferent.Name = "rdBtnDifferent";
            this.rdBtnDifferent.Size = new System.Drawing.Size(121, 17);
            this.rdBtnDifferent.TabIndex = 20;
            this.rdBtnDifferent.TabStop = true;
            this.rdBtnDifferent.Text = "People with different";
            this.rdBtnDifferent.UseVisualStyleBackColor = true;
            this.rdBtnDifferent.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(250, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "Event Name";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // txtEventName
            // 
            this.txtEventName.Location = new System.Drawing.Point(322, 32);
            this.txtEventName.Name = "txtEventName";
            this.txtEventName.Size = new System.Drawing.Size(153, 20);
            this.txtEventName.TabIndex = 22;
            this.txtEventName.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btnResources
            // 
            this.btnResources.Location = new System.Drawing.Point(703, 23);
            this.btnResources.Name = "btnResources";
            this.btnResources.Size = new System.Drawing.Size(85, 37);
            this.btnResources.TabIndex = 23;
            this.btnResources.Text = "Resources";
            this.btnResources.UseVisualStyleBackColor = true;
            this.btnResources.Click += new System.EventHandler(this.btnResources_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(322, 74);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 24;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(258, 80);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 25;
            this.label7.Text = "EventDate";
            // 
            // btnHistory
            // 
            this.btnHistory.Location = new System.Drawing.Point(703, 104);
            this.btnHistory.Name = "btnHistory";
            this.btnHistory.Size = new System.Drawing.Size(85, 40);
            this.btnHistory.TabIndex = 26;
            this.btnHistory.Text = "History";
            this.btnHistory.UseVisualStyleBackColor = true;
            this.btnHistory.Click += new System.EventHandler(this.btnHistory_Click);
            // 
            // FormSeatingPlan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnHistory);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btnResources);
            this.Controls.Add(this.txtEventName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.rdBtnDifferent);
            this.Controls.Add(this.rdBtnSame);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtColNameSittingPlan);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtOutputFileName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnStartProcess);
            this.Controls.Add(this.txtFolderName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnBrowseFolder);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBrowseFile);
            this.Controls.Add(this.txtFileName);
            this.Name = "FormSeatingPlan";
            this.Text = "SeatingPlan";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStartProcess;
        private System.Windows.Forms.TextBox txtFolderName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBrowseFolder;
        private System.Windows.Forms.OpenFileDialog fileDialogeBrowse;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtOutputFileName;
        private System.Windows.Forms.TextBox txtFileName;
        private System.Windows.Forms.Button btnBrowseFile;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtColNameSittingPlan;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton rdBtnSame;
        private System.Windows.Forms.RadioButton rdBtnDifferent;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtEventName;
        private System.Windows.Forms.Button btnResources;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnHistory;
    }
}

